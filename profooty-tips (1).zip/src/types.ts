export interface Tip {
  id: number;
  match_title: string;
  league: string;
  prediction: string;
  odds: string;
  confidence: number;
  category: 'free' | 'over_under' | 'safe' | 'basket' | 'combine';
  status: 'pending' | 'won' | 'lost';
  created_at: string;
}
