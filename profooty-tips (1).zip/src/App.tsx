import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Trophy, 
  Settings, 
  Plus, 
  Trash2, 
  Edit2, 
  CheckCircle2, 
  XCircle, 
  Clock,
  ChevronRight,
  LayoutDashboard,
  Eye,
  TrendingUp,
  ShieldCheck,
  History,
  Zap,
  Target,
  ShoppingBasket,
  Layers,
  Lock,
  CreditCard,
  ChevronLeft,
  Sun,
  Moon,
  ExternalLink,
  Link as LinkIcon
} from 'lucide-react';
import { Tip } from './types';

type Category = 'free' | 'over_under' | 'safe' | 'basket' | 'combine' | 'history';

const CATEGORIES: { id: Category; label: string; icon: any; color: string; isPremium: boolean }[] = [
  { id: 'free', label: 'Free Tips', icon: Zap, color: 'text-emerald-400', isPremium: false },
  { id: 'over_under', label: 'Over/Under', icon: Target, color: 'text-yellow-400', isPremium: true },
  { id: 'safe', label: 'Safe Picks', icon: ShieldCheck, color: 'text-emerald-400', isPremium: true },
  { id: 'basket', label: 'Basketball', icon: ShoppingBasket, color: 'text-orange-400', isPremium: true },
  { id: 'combine', label: 'Combine', icon: Layers, color: 'text-blue-400', isPremium: true },
  { id: 'history', label: 'History', icon: History, color: 'text-zinc-400', isPremium: false },
];

const COMMON_LEAGUES = [
  "English Premier League", "Spanish La Liga", "German Bundesliga", "Italian Serie A", 
  "French Ligue 1", "UEFA Champions League", "UEFA Europa League", "Tanzania Premier League",
  "Kenya Premier League", "South Africa PSL", "Nigeria NPFL", "CAF Champions League",
  "MLS", "Brazil Serie A", "Argentina Liga Profesional", "Netherlands Eredivisie",
  "Portugal Primeira Liga", "Turkey Super Lig", "Saudi Pro League"
];

const BASKETBALL_LEAGUES = [
  "NBA", "EuroLeague", "Spanish ACB", "Turkish BSL", "VTB United League", 
  "German BBL", "Italian Lega A", "French LNB Pro A", "NCAA", "CBA (China)",
  "NBL (Australia)", "Basketball Africa League (BAL)"
];

const COMMON_PREDICTIONS = [
  "Home Win", "Away Win", "Draw", "Home Win or Draw (1X)", "Away Win or Draw (X2)",
  "Home or Away (12)", "Both Teams to Score (BTTS)", "Over", "Under",
  "Home Over", "Away Over", "Home Win to Nil", "Away Win to Nil", 
  "Draw No Bet (DNB) Home", "Draw No Bet (DNB) Away"
];

export default function App() {
  const [tips, setTips] = useState<Tip[]>([]);
  const [activeCategory, setActiveCategory] = useState<Category>('free');
  const [isAdmin, setIsAdmin] = useState(false);
  const [isEditor, setIsEditor] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [loginType, setLoginType] = useState<'admin' | 'editor'>('admin');
  const [adminPassword, setAdminPassword] = useState('');
  const [isEditing, setIsEditing] = useState<Tip | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [summaries, setSummaries] = useState<any[]>([]);
  const [categorySettings, setCategorySettings] = useState<any[]>([]);
  const [globalSettings, setGlobalSettings] = useState({
    terms: '',
    privacy: '',
    contact: '',
    zeno_api_key: '',
    zeno_account_id: '',
    zeno_webhook_secret: '',
    zeno_sandbox: false,
    stripe_publishable_key: '',
    stripe_secret_key: ''
  });

  // Access control state
  const [unlockedCategories, setUnlockedCategories] = useState<Set<Category>>(new Set(['free', 'history']));
  const [showPaywall, setShowPaywall] = useState(false);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [paymentData, setPaymentData] = useState({
    name: '',
    email: '',
    phone: ''
  });
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [isWatchingAd, setIsWatchingAd] = useState(false);
  const [adProgress, setAdProgress] = useState(0);
  const [adsWatched, setAdsWatched] = useState(0);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [localGlobalSettings, setLocalGlobalSettings] = useState<any>(null);
  const [paymentMethod, setPaymentMethod] = useState<'zeno' | 'stripe'>('zeno');
  const [localCategorySettings, setLocalCategorySettings] = useState<any[]>([]);
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [selectedHistoryDate, setSelectedHistoryDate] = useState<string | null>(null);
  const [theme, setTheme] = useState<'light' | 'dark'>('dark');

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  // Form state
  const [formData, setFormData] = useState({
    match_title: '',
    league: '',
    prediction: '',
    odds: '',
    confidence: 85,
    category: 'free' as Category,
  });

  useEffect(() => {
    // Check for admin query parameter to show login
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('admin') === 'true') {
      setLoginType('admin');
      setShowAdminLogin(true);
      // Clean up URL without refreshing
      window.history.replaceState({}, document.title, window.location.pathname);
    }
    if (urlParams.get('editor') === 'true') {
      setLoginType('editor');
      setShowAdminLogin(true);
      window.history.replaceState({}, document.title, window.location.pathname);
    }

    fetchSummaries();
    fetchSettings();
    fetchGlobalSettings();
    fetchTips();
    // Reset history date selection when switching categories
    if (activeCategory !== 'history') {
      setSelectedHistoryDate(null);
    }
  }, [activeCategory, isAdmin, isEditor]);

  useEffect(() => {
    if (activeCategory === 'history' && tips.length > 0 && !selectedHistoryDate) {
      const getFriendlyDate = (dateStr: string) => {
        const date = new Date(dateStr);
        const today = new Date();
        const yesterday = new Date();
        yesterday.setDate(today.getDate() - 1);
        if (date.toDateString() === today.toDateString()) return "Today";
        if (date.toDateString() === yesterday.toDateString()) return "Yesterday";
        return date.toLocaleDateString(undefined, {
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        });
      };
      // Set default to the most recent date
      const mostRecentDate = getFriendlyDate(tips[0].created_at);
      setSelectedHistoryDate(mostRecentDate);
    }
  }, [tips, activeCategory]);

  const fetchGlobalSettings = async () => {
    try {
      const res = await fetch('/api/global-settings');
      const data = await res.json();
      const processedData = {
        ...data,
        zeno_sandbox: data.zeno_sandbox === 'true',
        stripe_publishable_key: data.stripe_publishable_key || '',
        stripe_secret_key: data.stripe_secret_key || ''
      };
      setGlobalSettings(processedData);
      setLocalGlobalSettings(processedData);
    } catch (error) {
      console.error('Failed to fetch global settings:', error);
    }
  };

  const fetchSettings = async () => {
    try {
      const res = await fetch('/api/settings');
      const data = await res.json();
      if (Array.isArray(data)) {
        const processed = data.map(s => ({
          ...s,
          ad_links: Array.isArray(s.ad_links) ? s.ad_links : [],
          buttons: Array.isArray(s.buttons) ? s.buttons : [],
          ads_required: s.ads_required || 2,
          price_usd: s.price_usd || '4.99'
        }));
        setCategorySettings(processed);
        setLocalCategorySettings(processed);
      }
    } catch (error) {
      console.error('Failed to fetch settings:', error);
    }
  };

  const handleSaveAllSettings = async () => {
    setIsSavingSettings(true);
    try {
      // Save Global Settings
      await fetch('/api/global-settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(localGlobalSettings)
      });

      // Save Category Settings
      for (const catSetting of localCategorySettings) {
        await fetch(`/api/settings/${catSetting.category}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(catSetting)
        });
      }

      await fetchGlobalSettings();
      await fetchSettings();
      alert('All settings saved successfully!');
      setShowSettingsModal(false);
    } catch (error) {
      console.error('Failed to save settings:', error);
      alert('Failed to save some settings.');
    } finally {
      setIsSavingSettings(false);
    }
  };

  const fetchSummaries = async () => {
    try {
      const res = await fetch('/api/tips/summary');
      const data = await res.json();
      if (Array.isArray(data)) {
        setSummaries(data);
      }
    } catch (error) {
      console.error('Failed to fetch summaries:', error);
    }
  };

  const fetchTips = async () => {
    // Check if category is premium and not unlocked
    const catInfo = CATEGORIES.find(c => c.id === activeCategory);
    if (!isAdmin && catInfo?.isPremium && !unlockedCategories.has(activeCategory)) {
      setTips([]);
      setLoading(false);
      setShowPaywall(true);
      return;
    }

    setLoading(true);
    setShowPaywall(false);
    try {
      let url = '/api/tips';
      if (activeCategory === 'history') {
        url += '?history=true';
      } else if (!isAdmin) {
        url += `?category=${activeCategory}`;
      }
      const res = await fetch(url);
      const data = await res.json();
      
      if (Array.isArray(data)) {
        setTips(data);
      } else {
        console.error('Received non-array data:', data);
        setTips([]);
      }
    } catch (error) {
      console.error('Failed to fetch tips:', error);
      setTips([]);
    } finally {
      setLoading(false);
    }
  };

  const handleWatchAd = () => {
    setIsWatchingAd(true);
    setAdProgress(0);
    const interval = setInterval(() => {
      setAdProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsWatchingAd(false);
          
          const settings = categorySettings.find(s => s.category === activeCategory);
          const required = settings?.ads_required || 2;

          setAdsWatched(current => {
            const next = current + 1;
            if (next >= required) {
              setUnlockedCategories(prevSet => new Set([...prevSet, activeCategory]));
              return 0;
            }
            return next;
          });
          return 100;
        }
        // Back to faster progress for single ad (approx 5s)
        return prev + 2;
      });
    }, 100);
  };

  const handlePayment = () => {
    setShowPaymentForm(true);
  };

  const handleInitiatePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessingPayment(true);
    
    const settings = categorySettings.find(s => s.category === activeCategory);
    const price = paymentMethod === 'zeno' ? (settings?.price || '10000') : (settings?.price_usd || '4.99');

    try {
      if (paymentMethod === 'stripe') {
        const res = await fetch('/api/payments/stripe/create-checkout-session', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            category: activeCategory,
            amount: price,
            buyer_email: paymentData.email
          })
        });
        const data = await res.json();
        if (data.url) {
          window.location.href = data.url;
          return;
        } else {
          throw new Error(data.error || 'Failed to create Stripe session');
        }
      } else {
        const res = await fetch('/api/payments/initiate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            category: activeCategory,
            amount: price,
            buyer_email: paymentData.email,
            buyer_phone: paymentData.phone,
            buyer_name: paymentData.name
          })
        });

        const data = await res.json();
        
        if (data.payment_url) {
          window.location.href = data.payment_url;
        } else if (data.success) {
          alert('Payment initiated! Please check your phone for the prompt.');
          setUnlockedCategories(prevSet => new Set([...prevSet, activeCategory]));
          setShowPaymentForm(false);
        } else {
          alert(data.error || 'Failed to initiate payment. Please check admin configuration.');
        }
      }
    } catch (error: any) {
      console.error('Payment error:', error);
      alert(error.message || 'An error occurred while processing payment.');
    } finally {
      setIsProcessingPayment(false);
    }
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginType === 'admin' && adminPassword === 'admin123') {
      setIsAdmin(true);
      setIsEditor(false);
      setShowAdminLogin(false);
      setAdminPassword('');
    } else if (loginType === 'editor' && adminPassword === 'editor123') {
      setIsEditor(true);
      setIsAdmin(false);
      setShowAdminLogin(false);
      setAdminPassword('');
    } else {
      alert('Incorrect password');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const url = isEditing ? `/api/tips/${isEditing.id}` : '/api/tips';
    const method = isEditing ? 'PUT' : 'POST';

    try {
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(isEditing ? { ...formData, status: isEditing.status } : formData),
      });

      if (res.ok) {
        fetchTips();
        setShowForm(false);
        setIsEditing(null);
        setFormData({ match_title: '', league: '', prediction: '', odds: '', confidence: 85, category: activeCategory === 'history' ? 'free' : activeCategory });
      }
    } catch (error) {
      console.error('Failed to save tip:', error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this tip?')) return;
    try {
      const res = await fetch(`/api/tips/${id}`, { method: 'DELETE' });
      if (res.ok) fetchTips();
    } catch (error) {
      console.error('Failed to delete tip:', error);
    }
  };

  const handleClearHistory = async () => {
    if (!confirm('Are you sure you want to clear ALL history? This cannot be undone.')) return;
    try {
      const res = await fetch('/api/tips/history/clear', { method: 'DELETE' });
      if (res.ok) {
        setSelectedHistoryDate(null);
        fetchTips();
        alert('History cleared successfully');
      } else {
        const error = await res.json();
        alert(`Failed to clear history: ${error.error || 'Unknown error'}`);
      }
    } catch (error) {
      console.error('Failed to clear history:', error);
      alert('Failed to clear history. Please check your connection.');
    }
  };

  const updateStatus = async (tip: Tip, status: 'won' | 'lost' | 'pending') => {
    try {
      const res = await fetch(`/api/tips/${tip.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...tip, status }),
      });
      if (res.ok) fetchTips();
    } catch (error) {
      console.error('Failed to update status:', error);
    }
  };

  const startEdit = (tip: Tip) => {
    setIsEditing(tip);
    setFormData({
      match_title: tip.match_title,
      league: tip.league,
      prediction: tip.prediction,
      odds: tip.odds,
      confidence: tip.confidence,
      category: tip.category,
    });
    setShowForm(true);
  };

  const renderTipCard = (tip: Tip) => (
    <div
      key={tip.id}
      className="p-8 bg-white dark:bg-white/[0.03] border border-zinc-200 dark:border-white/10 rounded-[32px] shadow-md hover:shadow-xl transition-all"
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <span className="px-3 py-1 bg-emerald-500/10 text-emerald-500 text-[10px] font-bold uppercase tracking-wider rounded-full border border-emerald-500/20">
              {tip.league}
            </span>
            {(isAdmin || activeCategory === 'history') && (
              <span className="px-3 py-1 bg-zinc-100 dark:bg-white/5 text-zinc-500 dark:text-zinc-400 text-[10px] font-bold uppercase tracking-wider rounded-full border border-zinc-200 dark:border-white/10">
                {CATEGORIES.find(c => c.id === tip.category)?.label || tip.category}
              </span>
            )}
            <span className="text-zinc-500 dark:text-zinc-400 text-xs flex items-center gap-1">
              <Clock size={12} />
              {new Date(tip.created_at).toLocaleDateString()}
            </span>
          </div>
          <h3 className="text-xl font-bold mb-1">{tip.match_title}</h3>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-zinc-500 dark:text-zinc-400 text-sm">Pick:</span>
              <span className="font-bold text-emerald-500 dark:text-emerald-400">{tip.prediction}</span>
            </div>
            <div className="w-px h-4 bg-zinc-200 dark:bg-white/10" />
            <div className="flex items-center gap-2">
              <span className="text-zinc-500 dark:text-zinc-400 text-sm">Odds:</span>
              <span className="font-bold">{tip.odds}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="text-right min-w-[100px]">
            <div className="text-[10px] uppercase tracking-widest text-zinc-400 dark:text-zinc-500 font-bold mb-1">Accuracy</div>
            <div className="flex items-center gap-2">
              <div className="flex-1 h-1.5 bg-zinc-100 dark:bg-white/10 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-emerald-500 transition-all duration-500" 
                  style={{ width: `${tip.confidence}%` }}
                />
              </div>
              <span className="text-xs font-bold text-emerald-500">{tip.confidence}%</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {(isAdmin || isEditor) ? (
              <div className="flex items-center gap-2 bg-zinc-50 dark:bg-black/40 p-1.5 rounded-2xl border border-zinc-200 dark:border-white/5">
                <button 
                  onClick={() => updateStatus(tip, 'won')}
                  className={`p-2 rounded-xl transition-all ${tip.status === 'won' ? 'bg-emerald-500 text-black' : 'hover:bg-zinc-100 dark:hover:bg-white/5 text-zinc-500'}`}
                  title="Mark as Won"
                >
                  <CheckCircle2 size={18} />
                </button>
                <button 
                  onClick={() => updateStatus(tip, 'lost')}
                  className={`p-2 rounded-xl transition-all ${tip.status === 'lost' ? 'bg-red-500 text-white' : 'hover:bg-zinc-100 dark:hover:bg-white/5 text-zinc-500'}`}
                  title="Mark as Lost"
                >
                  <XCircle size={18} />
                </button>
                <div className="w-px h-6 bg-zinc-200 dark:bg-white/10 mx-1" />
                <button 
                  onClick={() => startEdit(tip)}
                  className="p-2 rounded-xl hover:bg-zinc-100 dark:hover:bg-white/5 text-zinc-500 transition-all"
                  title="Edit Tip"
                >
                  <Edit2 size={18} />
                </button>
                <button 
                  onClick={() => handleDelete(tip.id)}
                  className="p-2 rounded-xl hover:bg-red-500/10 text-red-500 transition-all"
                  title="Delete Tip"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            ) : (
              <div className={`flex items-center gap-2 px-4 py-2 rounded-2xl border font-bold text-sm ${
                tip.status === 'won' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-500' :
                tip.status === 'lost' ? 'bg-red-500/10 border-red-500/20 text-red-500' :
                'bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10 text-zinc-500 dark:text-zinc-400'
              }`}>
                {tip.status === 'won' && <CheckCircle2 size={16} />}
                {tip.status === 'lost' && <XCircle size={16} />}
                {tip.status === 'pending' && <Clock size={16} />}
                {tip.status.toUpperCase()}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-bg-primary text-text-primary font-sans selection:bg-emerald-500/30 transition-colors duration-300">
      {/* Navigation */}
      <nav className="border-b border-border-subtle bg-bg-primary/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-6 h-20 flex items-center justify-between">
          <div 
            className="flex items-center gap-3 cursor-default"
            onClick={(e) => {
              if (e.detail === 3) {
                setLoginType('editor');
                setShowAdminLogin(true);
              }
            }}
          >
            <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <Trophy className="text-black w-6 h-6" />
            </div>
            <div>
              <h1 className="font-bold text-xl tracking-tight">PROFOOTY</h1>
              <p className="text-[10px] uppercase tracking-[0.2em] text-emerald-500 font-semibold">Elite Predictions</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
              className="p-2.5 rounded-xl bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 border border-black/10 dark:border-white/10 transition-all text-zinc-500 dark:text-zinc-400"
              title={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
            >
              {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
            </button>
            {(isAdmin || isEditor) && (
              <div className="flex items-center gap-2">
                {isAdmin && (
                  <button 
                    onClick={() => setShowSettingsModal(true)}
                    className="p-2.5 rounded-xl bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 border border-black/10 dark:border-white/10 transition-all text-zinc-500 dark:text-zinc-400"
                    title="Category Settings"
                  >
                    <Settings size={20} />
                  </button>
                )}
                <button 
                  onClick={() => {
                    setIsAdmin(false);
                    setIsEditor(false);
                  }}
                  className="flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 transition-all text-sm font-medium"
                >
                  <Eye size={16} />
                  Exit {isAdmin ? 'Admin' : 'Editor'}
                </button>
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* Category Tabs (Public Only) */}
      {!(isAdmin || isEditor) && (
        <div className="bg-black/5 dark:bg-black/30 border-b border-border-subtle overflow-x-auto scrollbar-hide">
          <div className="max-w-5xl mx-auto px-6 flex items-center gap-8 h-14">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`flex items-center gap-2 h-full border-b-2 transition-all whitespace-nowrap text-sm font-bold ${
                  activeCategory === cat.id 
                    ? 'border-emerald-500 text-emerald-500' 
                    : 'border-transparent text-black dark:text-zinc-400 hover:text-emerald-500'
                }`}
              >
                <cat.icon size={16} className={activeCategory === cat.id ? cat.color : ''} />
                {cat.label}
              </button>
            ))}
          </div>
        </div>
      )}

      <main className="max-w-5xl mx-auto px-6 py-12">
        {/* Header Section */}
        <div className="mb-12">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col md:flex-row md:items-end justify-between gap-6"
          >
            <div>
              <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
                {isAdmin ? 'Admin Dashboard' : 
                 isEditor ? 'Tips Editor' :
                 activeCategory === 'history' ? 'Past Results' : 
                 CATEGORIES.find(c => c.id === activeCategory)?.label}
              </h2>
              <p className="text-zinc-500 dark:text-zinc-400 max-w-xl text-lg">
                {isAdmin 
                  ? 'Manage all predictions across all categories from one place.' 
                  : isEditor
                  ? 'Update and manage predictions for all categories.'
                  : activeCategory === 'history' 
                  ? 'Review our past performance and winning streaks.'
                  : `Elite ${CATEGORIES.find(c => c.id === activeCategory)?.label} predictions for today.`}
              </p>
            </div>
            {(isAdmin || isEditor) && (
              <button 
                onClick={() => {
                  setIsEditing(null);
                  setFormData({ match_title: '', league: '', prediction: '', odds: '', confidence: 85, category: activeCategory === 'history' ? 'free' : activeCategory });
                  setShowForm(true);
                }}
                className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-black px-6 py-3 rounded-2xl font-bold transition-all shadow-lg shadow-emerald-500/20"
              >
                <Plus size={20} />
                Post New Tip
              </button>
            )}
          </motion.div>
        </div>

        {/* Tips List */}
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : showPaywall ? (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-[40px] p-12 text-center max-w-2xl mx-auto"
          >
            <div className="w-20 h-20 bg-emerald-500/10 rounded-3xl flex items-center justify-center mx-auto mb-8 border border-emerald-500/20">
              <Lock className="text-emerald-500" size={40} />
            </div>
            <h3 className="text-3xl font-bold mb-2">Premium Category Locked</h3>
            
            {/* Odds Summary */}
            <div className="flex items-center justify-center gap-4 mb-8">
              <div className="bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 px-6 py-3 rounded-2xl">
                <div className="text-[10px] uppercase tracking-widest text-zinc-500 dark:text-zinc-400 font-bold mb-1">Total Odds</div>
                <div className="text-2xl font-bold text-emerald-400">
                  {summaries.find(s => s.category === activeCategory)?.totalOdds || "0.00"}
                </div>
              </div>
              <div className="bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 px-6 py-3 rounded-2xl">
                <div className="text-[10px] uppercase tracking-widest text-zinc-500 dark:text-zinc-400 font-bold mb-1">Tips Count</div>
                <div className="text-2xl font-bold">
                  {summaries.find(s => s.category === activeCategory)?.count || 0}
                </div>
              </div>
            </div>

            <p className="text-zinc-500 dark:text-zinc-400 mb-10 text-lg">
              This category contains our most accurate, high-accuracy predictions. Unlock it to see today's winning picks.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <button 
                onClick={handlePayment}
                className="bg-emerald-500 hover:bg-emerald-400 text-black font-bold py-5 rounded-2xl transition-all shadow-lg shadow-emerald-500/20 flex flex-col items-center justify-center gap-1"
              >
                <span className="text-lg">Instant Unlock</span>
                <span className="text-xs opacity-70">One-time payment of ${categorySettings.find(s => s.category === activeCategory)?.price || '4.99'}</span>
              </button>
              
              <button 
                onClick={() => {
                  const settings = categorySettings.find(s => s.category === activeCategory);
                  const adLinks = settings?.ad_links || [];
                  
                  if (adLinks.length === 0) {
                    alert("Ads are currently unavailable for this category. Please try again later or use Instant Unlock.");
                    return;
                  }

                  // Pick a link based on adsWatched
                  const adLink = adLinks[adsWatched % adLinks.length];
                  
                  const adWindow = window.open(adLink, '_blank');
                  if (!adWindow) {
                    alert("Please allow popups to watch ads and unlock this category.");
                    return;
                  }
                  handleWatchAd();
                }}
                disabled={isWatchingAd}
                className="bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 border border-black/10 dark:border-white/10 text-text-primary font-bold py-5 rounded-2xl transition-all flex flex-col items-center justify-center gap-1 relative overflow-hidden"
              >
                {isWatchingAd ? (
                  <>
                    <span className="text-lg z-10">Watching Ad...</span>
                    <div 
                      className="absolute bottom-0 left-0 h-1 bg-emerald-500 transition-all duration-100" 
                      style={{ width: `${adProgress}%` }}
                    />
                  </>
                ) : (
                  <>
                    <span className="text-lg">
                      Watch {categorySettings.find(s => s.category === activeCategory)?.ads_required || 2} Ads
                    </span>
                    <span className="text-xs text-zinc-500 dark:text-zinc-400">
                      {adsWatched === 0 
                        ? `0/${categorySettings.find(s => s.category === activeCategory)?.ads_required || 2} watched` 
                        : `${adsWatched}/${categorySettings.find(s => s.category === activeCategory)?.ads_required || 2} watched - Next one to unlock`}
                    </span>
                  </>
                )}
              </button>
            </div>
            <p className="mt-8 text-xs text-zinc-500 dark:text-zinc-400">
              By unlocking, you get full access to all tips in this category for the next 24 hours.
            </p>
          </motion.div>
        ) : (
          <div className="space-y-6">
            <AnimatePresence mode="popLayout">
              {tips.length === 0 ? (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center py-20 bg-white dark:bg-white/5 rounded-[40px] border border-dashed border-zinc-200 dark:border-white/10 shadow-sm"
                >
                  <p className="text-zinc-500 dark:text-zinc-400">No tips found in this category. Check back later!</p>
                </motion.div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-transparent border-none rounded-none overflow-visible"
                >
                  <div className="p-8 mb-6 bg-white dark:bg-white/5 border border-zinc-200 dark:border-white/10 rounded-[40px] shadow-md flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-emerald-500/10 rounded-xl flex items-center justify-center border border-emerald-500/20">
                        {React.createElement(CATEGORIES.find(c => c.id === (isAdmin ? tips[0].category : activeCategory))?.icon || Trophy, { className: "text-emerald-500", size: 20 })}
                      </div>
                      <div>
                        <h4 className="font-bold text-lg">
                          {isAdmin ? "All Active Tips" : CATEGORIES.find(c => c.id === activeCategory)?.label}
                        </h4>
                        <p className="text-xs text-zinc-500">
                          {tips.length} {tips.length === 1 ? 'Prediction' : 'Predictions'} Available
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      {isAdmin && activeCategory === 'history' && tips.length > 0 && (
                        <button
                          onClick={handleClearHistory}
                          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500/20 transition-all text-xs font-bold uppercase tracking-wider"
                        >
                          <Trash2 size={14} />
                          Clear History
                        </button>
                      )}
                      {!isAdmin && activeCategory !== 'history' && (
                        <div className="text-right">
                          <div className="text-[10px] uppercase tracking-widest text-zinc-400 dark:text-zinc-500 font-bold">Total Odds</div>
                          <div className="text-xl font-bold text-emerald-500 dark:text-emerald-400">
                            {summaries.find(s => s.category === activeCategory)?.totalOdds || "0.00"}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="space-y-4">
                    {activeCategory === 'history' ? (
                      (() => {
                        const getFriendlyDate = (dateStr: string) => {
                          const date = new Date(dateStr);
                          const today = new Date();
                          const yesterday = new Date();
                          yesterday.setDate(today.getDate() - 1);

                          if (date.toDateString() === today.toDateString()) return "Today";
                          if (date.toDateString() === yesterday.toDateString()) return "Yesterday";
                          
                          return date.toLocaleDateString(undefined, {
                            weekday: 'long',
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric'
                          });
                        };

                        const grouped = tips.reduce((groups: Record<string, Tip[]>, tip: Tip) => {
                          const dateLabel = getFriendlyDate(tip.created_at);
                          if (!groups[dateLabel]) groups[dateLabel] = [];
                          groups[dateLabel].push(tip);
                          return groups;
                        }, {});

                        const dates = Object.keys(grouped);

                        return (
                          <div className="flex flex-col">
                            <div className="p-6 bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-[32px] overflow-x-auto scrollbar-hide mb-6">
                              <div className="flex items-center gap-3">
                                {dates.map(date => (
                                  <button
                                    key={date}
                                    onClick={() => setSelectedHistoryDate(date)}
                                    className={`px-6 py-2.5 rounded-2xl text-sm font-bold transition-all whitespace-nowrap border ${
                                      selectedHistoryDate === date
                                        ? 'bg-emerald-500 text-black border-emerald-500 shadow-lg shadow-emerald-500/20'
                                        : 'bg-white dark:bg-white/5 text-black dark:text-zinc-400 border-zinc-200 dark:border-white/10 hover:bg-zinc-50 dark:hover:bg-white/10 hover:text-emerald-500 shadow-sm'
                                    }`}
                                  >
                                    {date}
                                  </button>
                                ))}
                              </div>
                            </div>
                            <div className="space-y-4">
                              {selectedHistoryDate && grouped[selectedHistoryDate] ? (
                                grouped[selectedHistoryDate].map(renderTipCard)
                              ) : (
                                <div className="p-20 text-center text-zinc-500 bg-white dark:bg-white/5 rounded-[40px] border border-dashed border-zinc-200 dark:border-white/10 shadow-sm">
                                  Select a date to view history
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })()
                    ) : (
                      tips.map(renderTipCard)
                    )}
                  </div>

                  {/* Custom Buttons Section */}
                  {!isAdmin && activeCategory !== 'history' && (
                    <div className="mt-8 flex flex-wrap gap-4 justify-center">
                      {(categorySettings.find(s => s.category === activeCategory)?.buttons || []).map((btn: any, idx: number) => (
                        <a 
                          key={idx}
                          href={btn.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 px-6 py-3 bg-blue-500 hover:bg-blue-400 text-white font-bold rounded-2xl transition-all shadow-lg shadow-blue-500/20 text-sm"
                        >
                          <LinkIcon size={16} />
                          {btn.label}
                          <ExternalLink size={14} />
                        </a>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </main>

      {/* Payment Details Modal */}
      <AnimatePresence>
        {showPaymentForm && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowPaymentForm(false)}
              className="absolute inset-0 bg-black/90 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="relative w-full max-w-md bg-bg-secondary border border-border-subtle rounded-[32px] p-8 shadow-2xl"
            >
              <div className="flex flex-col items-center text-center mb-8">
                <div className="w-16 h-16 bg-emerald-500/10 rounded-2xl flex items-center justify-center mb-4 border border-emerald-500/20">
                  <CreditCard className="text-emerald-500" size={32} />
                </div>
                <h3 className="text-2xl font-bold">Unlock Category</h3>
                <p className="text-zinc-500 text-sm mt-2">Choose your preferred payment method.</p>
              </div>

              <div className="flex gap-2 mb-8 p-1 bg-black/5 dark:bg-white/5 rounded-2xl border border-black/5 dark:border-white/5">
                <button 
                  onClick={() => setPaymentMethod('zeno')}
                  className={`flex-1 py-3 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${
                    paymentMethod === 'zeno' 
                      ? 'bg-emerald-500 text-black shadow-lg shadow-emerald-500/20' 
                      : 'text-zinc-500 hover:text-text-primary'
                  }`}
                >
                  Mobile Money (TSH)
                </button>
                <button 
                  onClick={() => setPaymentMethod('stripe')}
                  className={`flex-1 py-3 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${
                    paymentMethod === 'stripe' 
                      ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/20' 
                      : 'text-zinc-500 hover:text-text-primary'
                  }`}
                >
                  Card (USD)
                </button>
              </div>

              <form onSubmit={handleInitiatePayment} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Full Name</label>
                  <input 
                    required
                    value={paymentData.name}
                    onChange={e => setPaymentData({...paymentData, name: e.target.value})}
                    placeholder="John Doe"
                    className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl px-4 py-3 focus:outline-none focus:border-emerald-500 transition-all text-text-primary"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Email Address</label>
                  <input 
                    required
                    type="email"
                    value={paymentData.email}
                    onChange={e => setPaymentData({...paymentData, email: e.target.value})}
                    placeholder="john@example.com"
                    className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl px-4 py-3 focus:outline-none focus:border-emerald-500 transition-all text-text-primary"
                  />
                </div>
                {paymentMethod === 'zeno' && (
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Phone Number (M-Pesa/TigoPesa)</label>
                    <input 
                      required
                      type="tel"
                      value={paymentData.phone}
                      onChange={e => setPaymentData({...paymentData, phone: e.target.value})}
                      placeholder="255..."
                      className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl px-4 py-4 focus:outline-none focus:border-emerald-500 transition-all text-lg text-text-primary"
                    />
                  </div>
                )}
                
                <div className="pt-4">
                  <button 
                    type="submit"
                    disabled={isProcessingPayment}
                    className={`w-full font-bold py-4 rounded-2xl transition-all shadow-lg flex items-center justify-center gap-2 ${
                      paymentMethod === 'stripe' 
                        ? 'bg-blue-500 hover:bg-blue-400 text-white shadow-blue-500/20' 
                        : 'bg-emerald-500 hover:bg-emerald-400 text-black shadow-emerald-500/20'
                    }`}
                  >
                    {isProcessingPayment ? (
                      <div className={`w-5 h-5 border-2 border-t-transparent rounded-full animate-spin ${paymentMethod === 'stripe' ? 'border-white' : 'border-black'}`} />
                    ) : (
                      <>
                        Pay {paymentMethod === 'zeno' ? 'TSH ' : '$'}
                        {paymentMethod === 'zeno' 
                          ? (categorySettings.find(s => s.category === activeCategory)?.price || '10000')
                          : (categorySettings.find(s => s.category === activeCategory)?.price_usd || '4.99')
                        }
                      </>
                    )}
                  </button>
                </div>
                <button 
                  type="button"
                  onClick={() => setShowPaymentForm(false)}
                  className="w-full text-zinc-500 text-sm hover:text-white transition-colors"
                >
                  Cancel
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Category Settings Modal */}
      <AnimatePresence>
        {showSettingsModal && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowSettingsModal(false)}
              className="absolute inset-0 bg-black/90 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="relative w-full max-w-2xl bg-bg-secondary border border-border-subtle rounded-[32px] p-8 shadow-2xl max-h-[80vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-2xl font-bold">Category Settings</h3>
                <button onClick={() => setShowSettingsModal(false)} className="text-zinc-500 hover:text-white">
                  <XCircle size={24} />
                </button>
              </div>

              <div className="space-y-6 pb-24">
                <div className="bg-emerald-500/5 border border-emerald-500/20 rounded-2xl p-6 mb-8">
                  <h4 className="font-bold mb-4 flex items-center gap-2">
                    <LayoutDashboard size={18} className="text-emerald-500" />
                    Global Website Info
                  </h4>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Contact Info (Email/Phone)</label>
                      <input 
                        value={localGlobalSettings?.contact || ''}
                        onChange={(e) => setLocalGlobalSettings({...localGlobalSettings, contact: e.target.value})}
                        className="w-full bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 rounded-xl px-4 py-2 focus:outline-none focus:border-emerald-500 transition-all text-text-primary"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Terms of Service</label>
                      <textarea 
                        value={localGlobalSettings?.terms || ''}
                        onChange={(e) => setLocalGlobalSettings({...localGlobalSettings, terms: e.target.value})}
                        rows={2}
                        className="w-full bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 rounded-xl px-4 py-2 focus:outline-none focus:border-emerald-500 transition-all resize-none text-text-primary"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Privacy Policy</label>
                      <textarea 
                        value={localGlobalSettings?.privacy || ''}
                        onChange={(e) => setLocalGlobalSettings({...localGlobalSettings, privacy: e.target.value})}
                        rows={2}
                        className="w-full bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 rounded-xl px-4 py-2 focus:outline-none focus:border-emerald-500 transition-all resize-none text-text-primary"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end mt-4">
                    <button 
                      onClick={handleSaveAllSettings}
                      disabled={isSavingSettings}
                      className="bg-emerald-500 hover:bg-emerald-400 text-black font-bold py-2 px-6 rounded-xl transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 text-sm"
                    >
                      {isSavingSettings ? (
                        <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <>Save Global Info</>
                      )}
                    </button>
                  </div>
                </div>

                <div className="bg-blue-500/5 border border-blue-500/20 rounded-2xl p-6 mb-8">
                  <h4 className="font-bold mb-4 flex items-center gap-2">
                    <ShieldCheck size={18} className="text-blue-500" />
                    ZenoPay Configuration
                  </h4>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">ZenoPay API Key</label>
                      <input 
                        type="password"
                        value={localGlobalSettings?.zeno_api_key || ''}
                        onChange={(e) => setLocalGlobalSettings({...localGlobalSettings, zeno_api_key: e.target.value})}
                        className="w-full bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 rounded-xl px-4 py-2 focus:outline-none focus:border-blue-500 transition-all text-text-primary"
                      />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Account ID</label>
                        <input 
                          value={localGlobalSettings?.zeno_account_id || ''}
                          onChange={(e) => setLocalGlobalSettings({...localGlobalSettings, zeno_account_id: e.target.value})}
                          className="w-full bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 rounded-xl px-4 py-2 focus:outline-none focus:border-blue-500 transition-all text-text-primary"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Webhook Secret</label>
                        <input 
                          type="password"
                          value={localGlobalSettings?.zeno_webhook_secret || ''}
                          onChange={(e) => setLocalGlobalSettings({...localGlobalSettings, zeno_webhook_secret: e.target.value})}
                          className="w-full bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 rounded-xl px-4 py-2 focus:outline-none focus:border-blue-500 transition-all text-text-primary"
                        />
                      </div>
                    </div>
                    <div className="flex items-center gap-3 pt-2">
                      <button 
                        onClick={() => setLocalGlobalSettings({...localGlobalSettings, zeno_sandbox: !localGlobalSettings?.zeno_sandbox})}
                        className={`w-12 h-6 rounded-full transition-all relative ${localGlobalSettings?.zeno_sandbox ? 'bg-orange-500' : 'bg-zinc-700'}`}
                      >
                        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${localGlobalSettings?.zeno_sandbox ? 'left-7' : 'left-1'}`} />
                      </button>
                      <span className="text-xs font-bold uppercase tracking-widest text-zinc-500">Sandbox Mode (Testing)</span>
                    </div>
                  </div>
                </div>

                <div className="bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl p-6 space-y-4">
                  <div className="flex items-center gap-3 mb-2">
                    <CreditCard size={20} className="text-blue-500" />
                    <h4 className="font-bold">Stripe Configuration (Card Payments)</h4>
                  </div>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Publishable Key</label>
                      <input 
                        value={localGlobalSettings?.stripe_publishable_key || ''}
                        onChange={(e) => setLocalGlobalSettings({...localGlobalSettings, stripe_publishable_key: e.target.value})}
                        placeholder="pk_live_..."
                        className="w-full bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 rounded-xl px-4 py-2 focus:outline-none focus:border-blue-500 transition-all text-text-primary"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Secret Key</label>
                      <input 
                        type="password"
                        value={localGlobalSettings?.stripe_secret_key || ''}
                        onChange={(e) => setLocalGlobalSettings({...localGlobalSettings, stripe_secret_key: e.target.value})}
                        placeholder="sk_live_..."
                        className="w-full bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 rounded-xl px-4 py-2 focus:outline-none focus:border-blue-500 transition-all text-text-primary"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-2">
                  <button 
                    onClick={handleSaveAllSettings}
                    disabled={isSavingSettings}
                    className="bg-emerald-500 hover:bg-emerald-400 text-black font-bold py-2 px-6 rounded-xl transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 text-sm"
                  >
                    {isSavingSettings ? (
                      <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <>Save All Configurations</>
                    )}
                  </button>
                </div>

                <h4 className="font-bold px-2 text-zinc-400 uppercase text-xs tracking-widest pt-4">Category Pricing, Ads & Buttons</h4>
                {CATEGORIES.filter(c => c.isPremium || c.id === 'free').map(cat => {
                  const settings = localCategorySettings.find(s => s.category === cat.id) || { price: '4.99', ad_links: [], buttons: [] };
                  const adLinks = settings.ad_links || [];
                  const buttons = settings.buttons || [];

                  return (
                    <div key={cat.id} className="bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl p-6 space-y-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <cat.icon size={20} className={cat.color} />
                          <h4 className="font-bold">{cat.label}</h4>
                        </div>
                        {cat.isPremium && (
                          <div className="flex items-center gap-4">
                            <div className="flex items-center gap-2">
                              <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">Price (TSH)</label>
                              <input 
                                value={settings.price}
                                onChange={(e) => {
                                  const newPrice = e.target.value;
                                  setLocalCategorySettings(prev => prev.map(s => s.category === cat.id ? {...s, price: newPrice} : s));
                                }}
                                className="w-24 bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 rounded-lg px-3 py-1 focus:outline-none focus:border-emerald-500 transition-all text-text-primary text-sm"
                              />
                            </div>
                            <div className="flex items-center gap-2">
                              <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">Price (USD)</label>
                              <input 
                                value={settings.price_usd || '4.99'}
                                onChange={(e) => {
                                  const newPrice = e.target.value;
                                  setLocalCategorySettings(prev => prev.map(s => s.category === cat.id ? {...s, price_usd: newPrice} : s));
                                }}
                                className="w-20 bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 rounded-lg px-3 py-1 focus:outline-none focus:border-blue-500 transition-all text-text-primary text-sm"
                              />
                            </div>
                            <div className="flex items-center gap-2">
                              <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">Ads Required</label>
                              <input 
                                type="number"
                                min="1"
                                value={settings.ads_required || 2}
                                onChange={(e) => {
                                  const newVal = parseInt(e.target.value) || 1;
                                  setLocalCategorySettings(prev => prev.map(s => s.category === cat.id ? {...s, ads_required: newVal} : s));
                                }}
                                className="w-16 bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 rounded-lg px-3 py-1 focus:outline-none focus:border-emerald-500 transition-all text-text-primary text-sm"
                              />
                            </div>
                          </div>
                        )}
                      </div>

                      {cat.isPremium && (
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Ad Links (Watch to Unlock)</label>
                            <button 
                              onClick={() => {
                                const newLinks = [...adLinks, ''];
                                setLocalCategorySettings(prev => prev.map(s => s.category === cat.id ? {...s, ad_links: newLinks} : s));
                              }}
                              className="text-emerald-500 hover:text-emerald-400 text-xs font-bold flex items-center gap-1"
                            >
                              <Plus size={14} /> Add Link
                            </button>
                          </div>
                          <div className="space-y-2">
                            {adLinks.map((link: string, idx: number) => (
                              <div key={idx} className="flex gap-2">
                                <input 
                                  value={link}
                                  onChange={(e) => {
                                    const newLinks = [...adLinks];
                                    newLinks[idx] = e.target.value;
                                    setLocalCategorySettings(prev => prev.map(s => s.category === cat.id ? {...s, ad_links: newLinks} : s));
                                  }}
                                  placeholder="https://..."
                                  className="flex-1 bg-black/5 dark:bg-black/30 border border-black/10 dark:border-white/10 rounded-xl px-4 py-2 focus:outline-none focus:border-emerald-500 transition-all text-text-primary text-sm"
                                />
                                <button 
                                  onClick={() => {
                                    const newLinks = adLinks.filter((_: any, i: number) => i !== idx);
                                    setLocalCategorySettings(prev => prev.map(s => s.category === cat.id ? {...s, ad_links: newLinks} : s));
                                  }}
                                  className="p-2 text-red-500 hover:bg-red-500/10 rounded-xl transition-all"
                                >
                                  <Trash2 size={16} />
                                </button>
                              </div>
                            ))}
                            {adLinks.length === 0 && (
                              <p className="text-[10px] text-zinc-500 italic">No ad links added. Users won't be able to unlock via ads.</p>
                            )}
                          </div>
                        </div>
                      )}

                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Custom Buttons (Under Tips)</label>
                          <button 
                            onClick={() => {
                              const newButtons = [...buttons, { label: 'New Button', url: '' }];
                              setLocalCategorySettings(prev => prev.map(s => s.category === cat.id ? {...s, buttons: newButtons} : s));
                            }}
                            className="text-blue-500 hover:text-blue-400 text-xs font-bold flex items-center gap-1"
                          >
                            <Plus size={14} /> Add Button
                          </button>
                        </div>
                        <div className="space-y-2">
                          {buttons.map((btn: any, idx: number) => (
                            <div key={idx} className="grid grid-cols-2 gap-2 bg-black/5 dark:bg-black/20 p-3 rounded-xl border border-black/5 dark:border-white/5">
                              <div className="space-y-1">
                                <label className="text-[9px] uppercase font-bold text-zinc-500">Label</label>
                                <input 
                                  value={btn.label}
                                  onChange={(e) => {
                                    const newButtons = [...buttons];
                                    newButtons[idx] = { ...btn, label: e.target.value };
                                    setLocalCategorySettings(prev => prev.map(s => s.category === cat.id ? {...s, buttons: newButtons} : s));
                                  }}
                                  className="w-full bg-white dark:bg-black/30 border border-black/10 dark:border-white/10 rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:border-blue-500"
                                />
                              </div>
                              <div className="space-y-1 relative">
                                <label className="text-[9px] uppercase font-bold text-zinc-500">URL</label>
                                <div className="flex gap-2">
                                  <input 
                                    value={btn.url}
                                    onChange={(e) => {
                                      const newButtons = [...buttons];
                                      newButtons[idx] = { ...btn, url: e.target.value };
                                      setLocalCategorySettings(prev => prev.map(s => s.category === cat.id ? {...s, buttons: newButtons} : s));
                                    }}
                                    placeholder="https://..."
                                    className="flex-1 bg-white dark:bg-black/30 border border-black/10 dark:border-white/10 rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:border-blue-500"
                                  />
                                  <button 
                                    onClick={() => {
                                      const newButtons = buttons.filter((_: any, i: number) => i !== idx);
                                      setLocalCategorySettings(prev => prev.map(s => s.category === cat.id ? {...s, buttons: newButtons} : s));
                                    }}
                                    className="p-1.5 text-red-500 hover:bg-red-500/10 rounded-lg transition-all"
                                  >
                                    <Trash2 size={14} />
                                  </button>
                                </div>
                              </div>
                            </div>
                          ))}
                          {buttons.length === 0 && (
                            <p className="text-[10px] text-zinc-500 italic">No custom buttons added for this category.</p>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}

                <div className="flex justify-end pt-4">
                  <button 
                    onClick={handleSaveAllSettings}
                    disabled={isSavingSettings}
                    className="bg-emerald-500 hover:bg-emerald-400 text-black font-bold py-2 px-6 rounded-xl transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 text-sm"
                  >
                    {isSavingSettings ? (
                      <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <>Save Pricing & Ads</>
                    )}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Admin Login Modal */}
      <AnimatePresence>
        {showAdminLogin && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAdminLogin(false)}
              className="absolute inset-0 bg-black/90 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="relative w-full max-w-sm bg-bg-secondary border border-border-subtle rounded-[32px] p-8 shadow-2xl"
            >
              <div className="flex flex-col items-center text-center mb-8">
                <div className="w-16 h-16 bg-black/5 dark:bg-white/5 rounded-2xl flex items-center justify-center mb-4 border border-black/10 dark:border-white/10">
                  <Lock className="text-emerald-500" size={32} />
                </div>
                <h3 className="text-2xl font-bold">{loginType === 'admin' ? 'Admin Portal' : 'Editor Portal'}</h3>
                <p className="text-zinc-500 text-sm mt-2">Enter your password to access {loginType === 'admin' ? 'management tools' : 'tip editing tools'}.</p>
              </div>

              <form onSubmit={handleAdminLogin} className="space-y-4">
                <input 
                  type="password"
                  autoFocus
                  value={adminPassword}
                  onChange={e => setAdminPassword(e.target.value)}
                  placeholder="Password"
                  className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl px-4 py-4 focus:outline-none focus:border-emerald-500 transition-all text-center text-lg tracking-widest text-text-primary"
                />
                <button 
                  type="submit"
                  className="w-full bg-emerald-500 hover:bg-emerald-400 text-black font-bold py-4 rounded-2xl transition-all shadow-lg shadow-emerald-500/20"
                >
                  Access Dashboard
                </button>
                <button 
                  type="button"
                  onClick={() => setShowAdminLogin(false)}
                  className="w-full text-zinc-500 text-sm hover:text-text-primary transition-colors"
                >
                  Cancel
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Modal Form */}
      <AnimatePresence>
        {showForm && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowForm(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-lg bg-bg-secondary border border-border-subtle rounded-[32px] overflow-hidden shadow-2xl"
            >
              <div className="p-8">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-2xl font-bold">{isEditing ? 'Edit Tip' : 'New Prediction'}</h3>
                  <button onClick={() => setShowForm(false)} className="text-zinc-500 hover:text-white">
                    <XCircle size={24} />
                  </button>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Category</label>
                    <div className="grid grid-cols-2 gap-2">
                      {CATEGORIES.filter(c => c.id !== 'history').map(cat => (
                        <button
                          key={cat.id}
                          type="button"
                          onClick={() => setFormData({...formData, category: cat.id})}
                          className={`flex items-center gap-2 px-4 py-3 rounded-xl border text-sm transition-all ${
                            formData.category === cat.id 
                              ? 'bg-emerald-500/10 border-emerald-500 text-emerald-500' 
                              : 'bg-black/5 dark:bg-white/5 border-black/10 dark:border-white/10 text-zinc-500 dark:text-zinc-400 hover:bg-black/10 dark:hover:bg-white/10'
                          }`}
                        >
                          <cat.icon size={16} />
                          {cat.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Match Title</label>
                    <input 
                      required
                      value={formData.match_title}
                      onChange={e => setFormData({...formData, match_title: e.target.value})}
                      placeholder="e.g. Real Madrid vs Barcelona"
                      className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl px-4 py-3 focus:outline-none focus:border-emerald-500 transition-all text-text-primary"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">League</label>
                      <div className="relative">
                        <input 
                          required
                          value={formData.league}
                          onChange={e => setFormData({...formData, league: e.target.value})}
                          placeholder="Search or select league"
                          list="league-options"
                          className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl px-4 py-3 focus:outline-none focus:border-emerald-500 transition-all text-text-primary"
                        />
                        <datalist id="league-options">
                          {(formData.category === 'basket' ? BASKETBALL_LEAGUES : COMMON_LEAGUES).map(league => (
                            <option key={league} value={league} />
                          ))}
                        </datalist>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Odds</label>
                      <input 
                        required
                        value={formData.odds}
                        onChange={e => setFormData({...formData, odds: e.target.value})}
                        placeholder="e.g. 1.95"
                        className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl px-4 py-3 focus:outline-none focus:border-emerald-500 transition-all text-text-primary"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Prediction</label>
                    <div className="relative">
                      <input 
                        required
                        value={formData.prediction}
                        onChange={e => {
                          const val = e.target.value;
                          setFormData({...formData, prediction: val});
                        }}
                        placeholder="Search or select prediction"
                        list="prediction-options"
                        className="w-full bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 rounded-2xl px-4 py-3 focus:outline-none focus:border-emerald-500 transition-all text-text-primary"
                      />
                      <datalist id="prediction-options">
                        {COMMON_PREDICTIONS.map(pred => (
                          <option key={pred} value={pred} />
                        ))}
                      </datalist>
                    </div>
                  </div>

                  {(formData.prediction.toLowerCase().includes('over') || formData.prediction.toLowerCase().includes('under')) && (
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">
                          {formData.category === 'basket' ? 'Points Threshold' : 'Goals Threshold'}
                        </label>
                        <span className="text-emerald-500 font-bold">
                          {formData.prediction.split(' ').pop()?.includes('.') ? '' : ''} 
                          {formData.prediction}
                        </span>
                      </div>
                      <div className="flex items-center gap-4">
                        <input 
                          type="range"
                          min={formData.category === 'basket' ? "100" : "0.5"}
                          max={formData.category === 'basket' ? "250" : "6.5"}
                          step={formData.category === 'basket' ? "0.5" : "0.5"}
                          value={parseFloat(formData.prediction.split(' ').pop() || (formData.category === 'basket' ? "150" : "2.5")) || (formData.category === 'basket' ? 150 : 2.5)}
                          onChange={e => {
                            const val = e.target.value;
                            const parts = formData.prediction.split(' ');
                            // If the last part is a number, replace it. Otherwise append it.
                            if (!isNaN(parseFloat(parts[parts.length - 1]))) {
                              parts[parts.length - 1] = val;
                            } else {
                              parts.push(val);
                            }
                            setFormData({...formData, prediction: parts.join(' ')});
                          }}
                          className="flex-1 accent-emerald-500 h-1.5 bg-black/10 dark:bg-white/10 rounded-lg appearance-none cursor-pointer"
                        />
                        <div className="bg-black/5 dark:bg-white/5 px-3 py-1 rounded-lg border border-black/10 dark:border-white/10 text-sm font-bold">
                          {formData.prediction.split(' ').pop()}
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <label className="text-xs font-bold uppercase tracking-widest text-zinc-500">Accuracy</label>
                      <span className="text-emerald-500 font-bold">{formData.confidence}%</span>
                    </div>
                    <input 
                      type="range"
                      min="1"
                      max="100"
                      value={formData.confidence}
                      onChange={e => setFormData({...formData, confidence: parseInt(e.target.value)})}
                      className="w-full accent-emerald-500"
                    />
                  </div>

                  <button 
                    type="submit"
                    className="w-full bg-emerald-500 hover:bg-emerald-400 text-black font-bold py-4 rounded-2xl transition-all shadow-lg shadow-emerald-500/20 mt-4"
                  >
                    {isEditing ? 'Update Tip' : 'Publish Tip'}
                  </button>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="border-t border-border-subtle py-12 mt-20">
        <div className="max-w-5xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3 opacity-50">
            <Trophy size={20} />
            <span className="font-bold tracking-tight">PROFOOTY</span>
          </div>
          <p 
            className="text-zinc-500 dark:text-zinc-400 text-sm cursor-default"
            onDoubleClick={() => {
              setLoginType('admin');
              setShowAdminLogin(true);
            }}
          >
            © 2024 ProFooty Elite Predictions. All rights reserved.
          </p>
          <div className="flex gap-6 text-zinc-500 dark:text-zinc-400 text-sm">
            <button 
              onClick={() => alert(`Terms of Service:\n\n${globalSettings.terms || 'No terms of service set.'}`)}
              className="hover:text-emerald-500 transition-colors"
            >
              Terms
            </button>
            <button 
              onClick={() => alert(`Privacy Policy:\n\n${globalSettings.privacy || 'No privacy policy set.'}`)}
              className="hover:text-emerald-500 transition-colors"
            >
              Privacy
            </button>
            <button 
              onClick={() => alert(`Contact Information:\n\n${globalSettings.contact || 'No contact information set.'}`)}
              className="hover:text-emerald-500 transition-colors"
            >
              Contact
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}

