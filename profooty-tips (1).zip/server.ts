import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import cors from "cors";
import Stripe from "stripe";

const db = (() => {
  try {
    return new Database("tips.db");
  } catch (err) {
    console.error("Failed to open database:", err);
    // Fallback to in-memory if file fails, or just rethrow
    return new Database(":memory:");
  }
})();

// Initialize database
try {
  db.exec(`
    CREATE TABLE IF NOT EXISTS tips (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      match_title TEXT NOT NULL,
      league TEXT NOT NULL,
      prediction TEXT NOT NULL,
      odds TEXT,
      confidence INTEGER DEFAULT 5,
      category TEXT NOT NULL DEFAULT 'safe',
      status TEXT DEFAULT 'pending',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  db.exec(`
    CREATE TABLE IF NOT EXISTS category_settings (
      category TEXT PRIMARY KEY,
      price TEXT DEFAULT '10000',
      price_usd TEXT DEFAULT '4.99',
      ad_links TEXT DEFAULT '[]',
      buttons TEXT DEFAULT '[]',
      ads_required INTEGER DEFAULT 2
    )
  `);

  db.exec(`
    CREATE TABLE IF NOT EXISTS global_settings (
      key TEXT PRIMARY KEY,
      value TEXT DEFAULT ''
    )
  `);
} catch (err) {
  console.error("Database initialization error:", err);
}

// Initialize default settings
const categories = ['free', 'over_under', 'safe', 'basket', 'combine'];
categories.forEach(cat => {
  db.prepare("INSERT OR IGNORE INTO category_settings (category) VALUES (?)").run(cat);
});

const defaultGlobalSettings = [
  { key: 'terms', value: 'Standard betting terms apply. Must be 18+.' },
  { key: 'privacy', value: 'We value your privacy. No data is shared with third parties.' },
  { key: 'contact', value: 'support@profooty.com' },
  { key: 'stripe_publishable_key', value: '' },
  { key: 'stripe_secret_key', value: '' }
];
defaultGlobalSettings.forEach(setting => {
  db.prepare("INSERT OR IGNORE INTO global_settings (key, value) VALUES (?, ?)").run(setting.key, setting.value);
});

// Migration: Add columns to category_settings if they don't exist
try {
  db.prepare("SELECT ads_required FROM category_settings LIMIT 1").get();
} catch (e) {
  try {
    // Check if ad_links exists first to decide which columns to add
    const columns = db.prepare("PRAGMA table_info(category_settings)").all();
    const hasAdLinks = columns.some((c: any) => c.name === 'ad_links');
    const hasButtons = columns.some((c: any) => c.name === 'buttons');
    const hasAdsRequired = columns.some((c: any) => c.name === 'ads_required');

    if (!hasAdLinks) db.exec("ALTER TABLE category_settings ADD COLUMN ad_links TEXT DEFAULT '[]'");
    if (!hasButtons) db.exec("ALTER TABLE category_settings ADD COLUMN buttons TEXT DEFAULT '[]'");
    if (!hasAdsRequired) db.exec("ALTER TABLE category_settings ADD COLUMN ads_required INTEGER DEFAULT 2");
    
    // Check for price_usd
    const hasPriceUsd = columns.some((c: any) => c.name === 'price_usd');
    if (!hasPriceUsd) db.exec("ALTER TABLE category_settings ADD COLUMN price_usd TEXT DEFAULT '4.99'");
    
    console.log("Updated category_settings table schema");
  } catch (err) {
    console.error("Migration for category_settings failed:", err);
  }
}

// Migration: Add category column if it doesn't exist (for existing databases)
try {
  db.prepare("SELECT category FROM tips LIMIT 1").get();
} catch (e) {
  try {
    db.exec("ALTER TABLE tips ADD COLUMN category TEXT NOT NULL DEFAULT 'safe'");
    console.log("Added category column to tips table");
  } catch (err) {
    console.error("Migration failed:", err);
  }
}

async function startServer() {
  try {
    const app = express();
    const PORT = 3000;

    app.use(cors());
    app.use(express.json());

    // Health check
    app.get("/health", (req, res) => {
      res.json({ status: "ok", timestamp: new Date().toISOString() });
    });

    // API Routes
    app.get("/api/global-settings", (req, res) => {
    try {
      const settings = db.prepare("SELECT * FROM global_settings").all();
      const settingsMap = settings.reduce((acc: any, curr: any) => {
        acc[curr.key] = curr.value;
        return acc;
      }, {});
      res.json(settingsMap);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch global settings" });
    }
  });

  app.put("/api/global-settings", (req, res) => {
    const { terms, privacy, contact, zeno_api_key, zeno_account_id, zeno_webhook_secret, zeno_sandbox } = req.body;
    try {
      const stmt = db.prepare("INSERT OR REPLACE INTO global_settings (key, value) VALUES (?, ?)");
      if (terms !== undefined) stmt.run('terms', terms);
      if (privacy !== undefined) stmt.run('privacy', privacy);
      if (contact !== undefined) stmt.run('contact', contact);
      if (zeno_api_key !== undefined) stmt.run('zeno_api_key', zeno_api_key);
      if (zeno_account_id !== undefined) stmt.run('zeno_account_id', zeno_account_id);
      if (zeno_webhook_secret !== undefined) stmt.run('zeno_webhook_secret', zeno_webhook_secret);
      if (zeno_sandbox !== undefined) stmt.run('zeno_sandbox', zeno_sandbox ? 'true' : 'false');
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update global settings" });
    }
  });

  // ZenoPay Payment Initiation
  app.post("/api/payments/stripe/create-checkout-session", async (req, res) => {
    const { category, amount, buyer_email } = req.body;
    
    try {
      // Get Stripe Secret Key from DB
      const secretKey = db.prepare("SELECT value FROM global_settings WHERE key = 'stripe_secret_key'").get()?.value;
      
      if (!secretKey) {
        return res.status(400).json({ error: "Stripe is not configured in admin settings." });
      }

      const stripe = new Stripe(secretKey);
      
      // Get category label
      const catLabels: Record<string, string> = {
        'over_under': 'Over/Under Tips',
        'safe': 'Safe Picks',
        'basket': 'Basketball Tips',
        'combine': 'Combine Tips'
      };
      
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [
          {
            price_data: {
              currency: 'usd',
              product_data: {
                name: `Unlock ${catLabels[category] || category} - 24h Access`,
              },
              unit_amount: Math.round(parseFloat(amount) * 100), // amount in cents
            },
            quantity: 1,
          },
        ],
        mode: 'payment',
        success_url: `${req.headers.origin}/?payment=success&category=${category}`,
        cancel_url: `${req.headers.origin}/?payment=cancel`,
        customer_email: buyer_email,
        metadata: {
          category: category
        }
      });

      res.json({ id: session.id, url: session.url });
    } catch (error: any) {
      console.error("Stripe session error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/payments/initiate", async (req, res) => {
    const { category, amount, buyer_email, buyer_phone, buyer_name } = req.body;
    
    try {
      const apiKey = db.prepare("SELECT value FROM global_settings WHERE key = 'zeno_api_key'").get() as any;
      const accountId = db.prepare("SELECT value FROM global_settings WHERE key = 'zeno_account_id'").get() as any;
      const sandbox = db.prepare("SELECT value FROM global_settings WHERE key = 'zeno_sandbox'").get() as any;

      if (!apiKey?.value || !accountId?.value) {
        return res.status(400).json({ error: "ZenoPay is not configured by admin" });
      }

      const isSandbox = sandbox?.value === 'true';
      const apiUrl = isSandbox ? "https://zenopay.co.tz/api/pay" : "https://zenopay.co.tz/api/pay"; // Both use same endpoint usually, or user might want to toggle behavior

      // ZenoPay API Request based on user provided snippet
      const payload = {
        number: buyer_phone,
        amount: amount,
        account_id: accountId.value,
        api_key: apiKey.value,
        order_id: `ORDER_${Date.now()}`
      };

      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });

      const data = await response.json();
      
      // Log for debugging if needed
      if (isSandbox) {
        console.log("ZenoPay Sandbox Mode Active");
        console.log("Payload:", payload);
        console.log("Response:", data);
      }

      res.json(data);
    } catch (error) {
      console.error("ZenoPay initiation error:", error);
      res.status(500).json({ error: "Failed to initiate payment" });
    }
  });

  app.get("/api/settings", (req, res) => {
    try {
      const settings = db.prepare("SELECT * FROM category_settings").all();
      const parsedSettings = settings.map((s: any) => ({
        ...s,
        ad_links: JSON.parse(s.ad_links || '[]'),
        buttons: JSON.parse(s.buttons || '[]')
      }));
      res.json(parsedSettings);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });

  app.put("/api/settings/:category", (req, res) => {
    const { category } = req.params;
    const { price, price_usd, ad_links, buttons, ads_required } = req.body;
    try {
      db.prepare(
        "UPDATE category_settings SET price = ?, price_usd = ?, ad_links = ?, buttons = ?, ads_required = ? WHERE category = ?"
      ).run(price, price_usd || '4.99', JSON.stringify(ad_links || []), JSON.stringify(buttons || []), ads_required || 2, category);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update settings" });
    }
  });

  app.get("/api/tips/summary", (req, res) => {
    try {
      const summary = db.prepare(`
        SELECT 
          category, 
          COUNT(*) as count,
          GROUP_CONCAT(odds) as all_odds
        FROM tips 
        WHERE status = 'pending'
        GROUP BY category
      `).all();

      const result = summary.map((s: any) => {
        const oddsArray = s.all_odds ? s.all_odds.split(',').map((o: string) => parseFloat(o)).filter((o: number) => !isNaN(o)) : [];
        const totalOdds = oddsArray.reduce((acc: number, curr: number) => acc * curr, 1);
        return {
          category: s.category,
          count: s.count,
          totalOdds: oddsArray.length > 0 ? totalOdds.toFixed(2) : "0.00"
        };
      });

      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch summary" });
    }
  });

  app.get("/api/tips", (req, res) => {
    const { category, history } = req.query;
    try {
      let query = "SELECT * FROM tips";
      const params: any[] = [];

      if (history === 'true') {
        query += " WHERE status != 'pending'";
      } else if (category) {
        query += " WHERE category = ? AND status = 'pending'";
        params.push(category);
      } else {
        query += " WHERE status = 'pending'";
      }

      query += " ORDER BY created_at DESC";
      const tips = db.prepare(query).all(...params);
      res.json(tips);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch tips" });
    }
  });

  app.post("/api/tips", (req, res) => {
    const { match_title, league, prediction, odds, confidence, category } = req.body;
    try {
      const info = db.prepare(
        "INSERT INTO tips (match_title, league, prediction, odds, confidence, category) VALUES (?, ?, ?, ?, ?, ?)"
      ).run(match_title, league, prediction, odds, confidence, category);
      res.json({ id: info.lastInsertRowid });
    } catch (error) {
      res.status(500).json({ error: "Failed to create tip" });
    }
  });

  app.put("/api/tips/:id", (req, res) => {
    const { id } = req.params;
    const { match_title, league, prediction, odds, confidence, status, category } = req.body;
    try {
      db.prepare(
        "UPDATE tips SET match_title = ?, league = ?, prediction = ?, odds = ?, confidence = ?, status = ?, category = ? WHERE id = ?"
      ).run(match_title, league, prediction, odds, confidence, status, category, id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update tip" });
    }
  });

  app.delete("/api/tips/history/clear", (req, res) => {
    try {
      db.prepare("DELETE FROM tips WHERE status != 'pending'").run();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to clear history" });
    }
  });

  app.delete("/api/tips/:id", (req, res) => {
    const { id } = req.params;
    try {
      db.prepare("DELETE FROM tips WHERE id = ?").run(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete tip" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(process.cwd(), "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(process.cwd(), "dist", "index.html"));
    });
  }

    app.listen(PORT, "0.0.0.0", () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error("Failed to start server:", error);
  }
}

startServer();
